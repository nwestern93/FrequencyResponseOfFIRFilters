function [H] = fourier_transform(h,n,w)
%FOURIER_TRANSFORM Performs the fourier transform on h.
%   This function performs the fourier transform on h and returns the
%   results as H. h is the signal to be transformed. n is the sample
%   indices of h. w is omega, and can be either from -pi to pi, or from 0
%   to pi, and it should have a high resolution to make H to be more like a
%   continuous signal.

z = exp(1i*w);
H = zeros(1,length(z));
for k=1:length(z)
    H(k) = 0;
    for i=1:length(n)
        temp = h(i)*(z(k)^(-1*n(i)));
        H(k) = H(k) + temp;
    end
end
end

